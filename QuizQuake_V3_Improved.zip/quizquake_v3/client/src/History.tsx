import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

type AttemptSummary = {
  id: string;
  subject: string;
  score: number;
  total: number;
  createdAt: string;
};

type Props = {
  playerName: string;
  attempts: AttemptSummary[];
};

export default function History({ playerName, attempts }: Props) {
  return <section className="history-wrap">
    <span className="eyebrow">YOUR PROGRESS</span>
    <h1>Attempt history</h1>
    <p className="muted">Saved results for {playerName || "your player name"}.</p>
    {attempts.length ? <>
      <div className="chart-card">
        <Bar data={{
          labels: attempts.slice(0, 8).map((_, index) => `Attempt ${attempts.length - index}`),
          datasets: [{
            label: "Score (%)",
            data: attempts.slice(0, 8).map(item => Math.round(item.score / item.total * 100)),
            backgroundColor: "#8b79f7",
            borderRadius: 7
          }]
        }} options={{ responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } }} />
      </div>
      <div className="history-list">
        {attempts.map(item => <div className="history-row" key={item.id}>
          <div><b>{item.subject}</b><small>{new Date(item.createdAt).toLocaleString()}</small></div>
          <strong>{item.score}/{item.total}</strong>
        </div>)}
      </div>
    </> : <div className="empty">No attempts found yet. Complete a quiz and your result will appear here.</div>}
  </section>;
}
