# Manual testing checklist

Use this after installing dependencies and starting the app. Record the actual result and date; do not mark a test as passed before trying it.

- [ ] Home page opens on desktop and mobile width.
- [ ] Empty name is rejected.
- [ ] Name shorter than two characters is rejected.
- [ ] Each of the four subjects loads a quiz.
- [ ] A selected option can be submitted.
- [ ] Timer reaches zero and submits the question.
- [ ] Final score matches the reviewed answers.
- [ ] Explanations appear in answer review.
- [ ] Attempt appears in history under the same player name.
- [ ] Attempt remains after restarting the API server.
- [ ] Invalid API payload receives HTTP 400.
- [ ] `npm test` completes successfully.
- [ ] `npm run build` completes successfully.

## Suggested test cases for the adaptive rule

| Current level | Answer sequence | Expected next level |
|---|---|---|
| Easy | Correct | Easy (streak 1) |
| Easy | Correct, Correct | Medium |
| Medium | Wrong | Easy |
| Hard | Correct, Correct | Hard (maximum level) |
| Easy | Wrong | Easy (minimum level) |
