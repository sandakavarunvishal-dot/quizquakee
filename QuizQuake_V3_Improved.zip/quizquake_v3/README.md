# QuizQuake – BrainStorm Arena (Version 3)

A student-sized full-stack quiz application built with React, TypeScript, Express and SQLite. This version addresses the improvement points listed in the Attempt #2 evaluation report.

## What is included

- Four subjects: Computer Science, Mathematics, Science and General Knowledge.
- Easy, Medium and Hard question levels, with a 12-question round.
- Adaptive rule: two correct answers in a row move the next question up one level; a wrong answer moves it down one level. The server checks each answer without sending the answer key with the question, and the next question is selected from the appropriate level.
- 30-second question timer with automatic submission when time expires.
- Result page with correct answers, explanations, time taken and a difficulty-wise radar chart.
- SQLite attempt history that remains after a server restart.
- Input validation with Zod, request size limit, Helmet headers, API rate limiting and JSON request logs.
- Unit and API tests for difficulty transitions, cohort estimate, health route and invalid requests.
- Responsive layout and an attempt-history score chart.

## Requirements

- Node.js 20 or later
- npm 10 or later

## Run locally

1. Extract the ZIP and open the `quizquake_v3` folder in VS Code.
2. Open the terminal in that folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the Vite address shown in the terminal (normally `http://localhost:5173`). The API runs on `http://localhost:4000`.

To build both parts, run `npm run build`. To run the server unit tests, run `npm test`.

The SQLite database file (`quizquake.sqlite`) is created automatically in the server working directory on first run. Back it up if you need to keep attempt records.

## Useful folders

- `client/src/App.tsx` – home, quiz and result flow
- `client/src/History.tsx` – saved attempt history and score chart
- `client/src/style.css` – responsive visual styling
- `server/src/questions.ts` – question bank
- `server/src/engine.ts` – adaptive difficulty and percentile estimate
- `server/src/store.ts` – SQLite persistence
- `server/src/app.ts` – API routes and validation
- `server/test/engine.test.ts` – unit tests

## Before submitting

Please run the project on your own computer, test each subject, complete a quiz, restart the server and confirm that attempt history remains available. Run `npm test` and `npm run build`, and include screenshots or a short demo video from your actual run. Do not claim tests passed unless you have run them locally.

## Notes and limitations

- The percentile is a simulated estimate using a simple statistical curve. It is not calculated from real student cohort data.
- The current question bank has five questions per subject at each difficulty. A 12-question round avoids repeating a question within that round.
- This is an educational prototype, not a production examination platform. Add authentication and per-user access controls before using it with real student records.
