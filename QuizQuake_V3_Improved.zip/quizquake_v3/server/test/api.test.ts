import { describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../src/app.js";

describe("QuizQuake API", () => {
  it("reports that the API is running", async () => {
    const response = await request(app).get("/api/health");
    expect(response.status).toBe(200);
    expect(response.body.status).toBe("ok");
  });

  it("rejects an unknown quiz difficulty", async () => {
    const response = await request(app).get("/api/questions?subject=Science&difficulty=Expert");
    expect(response.status).toBe(400);
  });

  it("rejects an invalid attempt instead of storing it", async () => {
    const response = await request(app).post("/api/attempts").send({ playerName: "A", subject: "Science", answers: [] });
    expect(response.status).toBe(400);
  });
});
