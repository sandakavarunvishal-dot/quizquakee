import type { Difficulty } from "./engine.js";

export type Question = {
  id: string; subject: string; difficulty: Difficulty; prompt: string;
  options: string[]; answer: number; explanation: string;
};

// The question bank is deliberately kept in one place so adding or correcting
// a question does not require changing the quiz logic.
const topics = [
  { subject: "Computer Science", sets: [
    ["Which data structure follows FIFO order?", ["Stack", "Queue", "Tree", "Graph"], 1, "A queue removes the item that was added first."],
    ["Which language runs natively in most web browsers?", ["C", "Java", "JavaScript", "SQL"], 2, "JavaScript is supported directly by modern browsers."],
    ["What does HTML mainly describe?", ["Page structure", "Database queries", "Network routing", "Image compression"], 0, "HTML provides the structure and meaning of web content."],
    ["Which SQL command reads rows from a table?", ["PUSH", "SELECT", "UPDATE", "DROP"], 1, "SELECT retrieves data from one or more tables."],
    ["What is the average lookup time of a hash table?", ["O(n²)", "O(n)", "O(1)", "O(log n)"], 2, "A well-designed hash table provides constant-time average lookup." ]
  ]},
  { subject: "Mathematics", sets: [
    ["What is 15% of 200?", ["15", "20", "30", "45"], 2, "0.15 multiplied by 200 equals 30."],
    ["What is the value of 7 × 8?", ["54", "56", "58", "64"], 1, "Seven groups of eight make fifty-six."],
    ["What is the square root of 144?", ["10", "11", "12", "14"], 2, "12 multiplied by 12 is 144."],
    ["If x + 9 = 17, what is x?", ["6", "7", "8", "9"], 2, "Subtract 9 from both sides to get x = 8."],
    ["What is the slope of y = 3x + 2?", ["2", "3", "5", "-3"], 1, "In y = mx + c, m is the slope." ]
  ]},
  { subject: "Science", sets: [
    ["Which gas do plants absorb during photosynthesis?", ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"], 2, "Plants use carbon dioxide and water to make glucose."],
    ["What is the SI unit of force?", ["Joule", "Newton", "Watt", "Pascal"], 1, "Force is measured in newtons."],
    ["Which part of a cell contains most genetic material?", ["Nucleus", "Ribosome", "Cell wall", "Vacuole"], 0, "The nucleus contains most of the cell's DNA in eukaryotes."],
    ["What is the chemical symbol for sodium?", ["So", "S", "Na", "N"], 2, "Na comes from the Latin name natrium."],
    ["Which planet is known for its prominent rings?", ["Mars", "Venus", "Saturn", "Mercury"], 2, "Saturn has a large and bright ring system." ]
  ]},
  { subject: "General Knowledge", sets: [
    ["What is the capital of India?", ["Mumbai", "New Delhi", "Kolkata", "Chennai"], 1, "New Delhi is the capital of India."],
    ["Which is the largest ocean on Earth?", ["Atlantic", "Indian", "Arctic", "Pacific"], 3, "The Pacific Ocean is the largest and deepest ocean."],
    ["How many sides does a hexagon have?", ["Five", "Six", "Seven", "Eight"], 1, "A hexagon is a six-sided polygon."],
    ["Which organisation publishes the World Economic Outlook?", ["WHO", "IMF", "UNICEF", "UNESCO"], 1, "The International Monetary Fund publishes the report."],
    ["What is the currency of Japan?", ["Won", "Yuan", "Yen", "Ringgit"], 2, "Japan's currency is the yen." ]
  ]}
] as const;

const difficultyPrompts: Record<Difficulty, string[]> = {
  Easy: ["", "", "", "", ""],
  Medium: ["Choose the best answer: ", "Select the correct statement: ", "Identify the right answer: ", "Which option is correct? ", "Pick the correct response: "],
  Hard: ["Apply the concept and answer: ", "Think carefully and choose: ", "Use your understanding to answer: ", "Select the most accurate answer: ", "Which answer is supported by the concept? "]
};

const levels: Difficulty[] = ["Easy", "Medium", "Hard"];
export const questionBank: Question[] = topics.flatMap((topic, topicIndex) =>
  levels.flatMap((difficulty, levelIndex) => topic.sets.map((item, itemIndex) => ({
    id: `${topicIndex + 1}-${levelIndex + 1}-${itemIndex + 1}`,
    subject: topic.subject,
    difficulty,
    prompt: `${difficultyPrompts[difficulty][itemIndex]}${item[0]}`,
    options: [...item[1]],
    answer: item[2],
    explanation: item[3]
  })))
);
