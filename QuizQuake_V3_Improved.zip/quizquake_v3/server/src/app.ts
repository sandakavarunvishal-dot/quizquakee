import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { questionBank } from "./questions.js";
import { calculatePercentile, nextDifficulty, type Difficulty } from "./engine.js";
import { listAttempts, saveAttempt } from "./store.js";

export const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "20kb" }));
app.use((req, res, next) => {
  const started = Date.now();
  res.on("finish", () => console.log(JSON.stringify({
    time: new Date().toISOString(), method: req.method, path: req.path,
    status: res.statusCode, durationMs: Date.now() - started
  })));
  next();
});
app.use("/api", rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));

const subjects = ["Computer Science", "Mathematics", "Science", "General Knowledge"] as const;
app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "QuizQuake" }));
app.get("/api/subjects", (_req, res) => res.json(subjects));
app.get("/api/questions", (req, res) => {
  const parsed = z.object({ subject: z.enum(subjects), difficulty: z.enum(["Easy", "Medium", "Hard"]) }).safeParse(req.query);
  if (!parsed.success) return res.status(400).json({ error: "Choose a valid subject and difficulty." });
  const questions = questionBank.filter(q => q.subject === parsed.data.subject && q.difficulty === parsed.data.difficulty)
    .map(({ answer: _answer, ...question }) => question);
  return res.json(questions);
});


const answerCheckSchema = z.object({ questionId: z.string().min(1).max(20), subject: z.enum(subjects), selectedOption: z.number().int().min(-1).max(3) });
app.post("/api/answer-check", (req, res) => {
  const parsed = answerCheckSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid answer." });
  const question = questionBank.find(q => q.id === parsed.data.questionId && q.subject === parsed.data.subject);
  if (!question) return res.status(404).json({ error: "Question not found." });
  return res.json({ correct: question.answer === parsed.data.selectedOption, correctOption: question.answer, explanation: question.explanation });
});

const submitSchema = z.object({
  playerName: z.string().trim().min(2).max(30).regex(/^[\p{L}\p{N} _.-]+$/u),
  subject: z.enum(subjects),
  answers: z.array(z.object({ questionId: z.string().min(1).max(20), selectedOption: z.number().int().min(-1).max(3), timeTaken: z.number().int().min(0).max(3600) })).min(1).max(20)
});
app.post("/api/attempts", (req, res) => {
  const parsed = submitSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Please check the name and submitted answers.", details: parsed.error.flatten() });
  const { playerName, subject, answers } = parsed.data;
  const checked = answers.map(answer => {
    const question = questionBank.find(q => q.id === answer.questionId && q.subject === subject);
    if (!question) return null;
    return { ...answer, correct: question.answer === answer.selectedOption, correctOption: question.answer, explanation: question.explanation, prompt: question.prompt, difficulty: question.difficulty, subject: question.subject };
  });
  if (checked.some(item => item === null)) return res.status(400).json({ error: "One or more question IDs are not valid for this subject." });
  const validAnswers = checked as NonNullable<typeof checked[number]>[];
  const score = validAnswers.filter(item => item.correct).length;
  const percentile = calculatePercentile(Math.round(score / validAnswers.length * 100));
  const attempt = saveAttempt({ playerName, subject, score, total: validAnswers.length, percentile, answers: validAnswers });
  return res.status(201).json({ ...attempt, answers: validAnswers });
});
app.get("/api/attempts", (req, res) => {
  const parsed = z.string().trim().min(2).max(30).safeParse(req.query.playerName);
  if (!parsed.success) return res.status(400).json({ error: "Enter a player name to view history." });
  return res.json(listAttempts(parsed.data));
});

// Kept as a small endpoint so the adaptive rule can be checked independently.
app.post("/api/difficulty/next", (req, res) => {
  const parsed = z.object({ difficulty: z.enum(["Easy", "Medium", "Hard"]), correct: z.boolean(), streak: z.number().int().min(0).max(1) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid difficulty update." });
  return res.json(nextDifficulty(parsed.data.difficulty as Difficulty, parsed.data.correct, parsed.data.streak));
});

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error("Request failed:", err);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});
