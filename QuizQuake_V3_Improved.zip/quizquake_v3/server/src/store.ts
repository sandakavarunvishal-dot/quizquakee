import Database from "better-sqlite3";
import { randomUUID } from "node:crypto";
import type { Difficulty } from "./engine.js";

const db = new Database(process.env.DB_FILE || "quizquake.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`CREATE TABLE IF NOT EXISTS attempts (
  id TEXT PRIMARY KEY, player_name TEXT NOT NULL, subject TEXT NOT NULL,
  score INTEGER NOT NULL, total INTEGER NOT NULL, percentile INTEGER NOT NULL,
  answers_json TEXT NOT NULL, created_at TEXT NOT NULL
)`);

export type SavedAttempt = {
  id: string; playerName: string; subject: string; score: number;
  total: number; percentile: number; answers: unknown[]; createdAt: string;
};

export function saveAttempt(input: Omit<SavedAttempt, "id" | "createdAt">): SavedAttempt {
  const attempt: SavedAttempt = {
    ...input, id: randomUUID(), createdAt: new Date().toISOString()
  };
  db.prepare(`INSERT INTO attempts (id, player_name, subject, score, total, percentile, answers_json, created_at)
    VALUES (@id, @playerName, @subject, @score, @total, @percentile, @answers, @createdAt)`)
    .run({ ...attempt, answers: JSON.stringify(attempt.answers) });
  return attempt;
}

export function listAttempts(playerName: string): SavedAttempt[] {
  const rows = db.prepare(`SELECT * FROM attempts WHERE player_name = ? ORDER BY created_at DESC LIMIT 50`).all(playerName) as any[];
  return rows.map(row => ({
    id: row.id, playerName: row.player_name, subject: row.subject,
    score: row.score, total: row.total, percentile: row.percentile,
    answers: JSON.parse(row.answers_json), createdAt: row.created_at
  }));
}
