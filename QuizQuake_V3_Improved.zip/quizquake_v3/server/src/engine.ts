export type Difficulty = "Easy" | "Medium" | "Hard";

// Two correct answers in a row move the learner up one level.
// A wrong answer moves the next question down one level.
export function nextDifficulty(current: Difficulty, correct: boolean, streak: number): {
  difficulty: Difficulty;
  streak: number;
} {
  const levels: Difficulty[] = ["Easy", "Medium", "Hard"];
  if (!correct) {
    return { difficulty: levels[Math.max(0, levels.indexOf(current) - 1)], streak: 0 };
  }

  const newStreak = streak + 1;
  if (newStreak >= 2) {
    return { difficulty: levels[Math.min(2, levels.indexOf(current) + 1)], streak: 0 };
  }
  return { difficulty: current, streak: newStreak };
}

export function calculatePercentile(score: number, cohortMean = 60, cohortStdDev = 15): number {
  if (cohortStdDev <= 0) return score >= cohortMean ? 100 : 0;
  // Logistic approximation is stable and easy to explain in a student project.
  const z = (score - cohortMean) / cohortStdDev;
  return Math.round((1 / (1 + Math.exp(-1.702 * z))) * 100);
}

export function pickNextDifficulty(current: Difficulty, correct: boolean, streak: number) {
  return nextDifficulty(current, correct, streak);
}
